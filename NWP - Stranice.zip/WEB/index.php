<?php
	# Start session
    session_start();

	# Database connection
	include "dbconn.php";

	# Variables MUST BE INTEGERS
	if(!isset($_GET['menu'])) { $_GET['menu'] =  1; $menu = (int)$_GET['menu']; }

	# Variables MUST BE STRINGS A-Z
    if(!isset($_POST['_action_']))  { $_POST['_action_'] = 'FALSE';  }
print 
'<!DOCTYPE html>
<head>
  <meta name="description" content="A site meant for helping people getting to know vocaloid music">
	<meta name="keywords" content="Hatsune Miku">
	<meta name="author" content="Tomislav_Stipic">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="style.css" type="text/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Orbitron|Yanone+Kaffeesatz|Open+Sans+Condensed:300|Indie+Flower" type="text/css" rel="stylesheet">
  <title> Vocaloid music </title>
</head>
<body>
  <div id="motd-container">
    <div id="nav">
      <a class="login_links" href="login.php">
      <h3 class="login">Log in/Sing up</h3>
      </a>
    </div>
      <h1 id="motd"> Vocaloid music </h1>
      <div id="homebar-container">
        <div class="homebar">
          <a href=index.php> <h5>Home</h5></a></div>
        <div class="homebar">
          <a href=about.html><h5>About</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Contact</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Another</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Another 2</h5></a></div>
      </div>
   </div>
   <h2 class="main">Hover over an album that piques your interest. Click on one to be taken to the of it about page. </h2>

     <!-- Tekstualni dio stranice -->

   <div id=article>
         <h4> Vocaloid. The term used to refer to a synthisised voice.
           Created by pre-recording voice samples of a real human being, and then
           proceeding to "teach" the specifc software designed for handling those
           samples how to handle them in order to achieve the desired
           results.
         </h4>
       </div>
   <div id="catalog">
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
     <div class="square">
       <a href="http://vocadb.net/" target="_blank">
         <div class="inner-square">
           <div class="album-names-background">
             <p class="album-names"> Ime albuma </p>
           </div>
         </div>
       </a>
     </div>
    </div>
  </div>
  <!-- Pozicioniranje logo-a -->

  <div id="donji-sidebar">
    <img id="logo_1" src="Images/Logo_2.png">
    <div id="about">
      <a  href="https://www.youtube.com/watch?v=rGy6FuGdeYk" target=_blank>
      <h7 > What inspires us! ®<h7>
      </a>
    </div>
    <img id="logo_2" src="Images/Logo_1.png">
  </div>
<body>';
