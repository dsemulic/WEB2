<!DOCTYPE html>
<head>
  <meta name="description" content="A site meant for helping people getting to know vocaloid music">
	<meta name="keywords" content="Hatsune Miku">
	<meta name="author" content="Tomislav_Stipic">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="style.css" type="text/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Orbitron|Yanone+Kaffeesatz|Open+Sans+Condensed:300|Indie+Flower" type="text/css" rel="stylesheet">
  <title> Vocaloid music Login </title>
</head>
<body>

  <!-- Pozicioniranje logo-a -->

  <div id="donji-sidebar">
    <img id="logo_1" src="Images/Logo_2.png">
    <div id="about">
      <a  href="https://www.youtube.com/watch?v=rGy6FuGdeYk" target=_blank>
      <h7 > What inspires us! ®<h7>
      </a>
    </div>
    <img id="logo_2" src="Images/Logo_1.png">
  </div>
  </body>

  <div id="motd-container">
    <div id="nav">
      <a class="login_links" href="login.php">
      <h3 class="login">Log in/Sing up</h3>
      </a>
    </div>
      <h1 id="motd"> Vocaloid music </h1>
      <div id="homebar-container">
        <div class="homebar">
          <a href=index.php> <h5>Home</h5></a></div>
        <div class="homebar">
          <a href=about.html><h5>About</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Contact</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Another</h5></a></div>
        <div class="homebar">
          <a href=index.php><h5>Another 2</h5></a></div>
      </div>
   </div>
   <form action="login.php" method="get">
<div id="login_container">
  <!-- title -->
  <div class="login-text">
    <h1>Login</h1>
  </div>
  <!-- user -->
<!---  < ?php
  if ($_POST['login_action'] == 'TRUE') {
    echo '<h2>Good day<h2>' . $_POST['username'];
}
else {
print '<form action="login.php" name="loginform" id="loginform" method="POST">
  <input type="hidden" id="login_action" name="login_action" value="TRUE">
  <div class="log-in-divs">
    <label type="hidden" for="username"/>
    <input type="text" class="form-control_log-in" id="username" placeholder="Username" name="firstname" />
  </div>
  <div class="log-in-divs">
    <label type="hidden" for="password"/>
    <input type="text" class="form-control_log-in" id="password" placeholder="password" name="password" />
  </div>
  <div class="log-in-divs">
    <input type="submit" class="btn btn-default" value="Log in" />
  </div>
</form>';
}
?>
-->
</div>
<div id="sing_up_container">
  <div class="login-text">
  <h1 >Sing up!</h1>
</div>
<!-- < ?php
if ($_POST['_ACTION_'] == 'sign_up_action') {
  echo '<h2>Welcome.</h2>
  <p>Username: ' . $_POST['firstname'] . '</p>
  <p>Password: ' . $_POST['lastname'] . '</p>
  <p>Gender: ' . $_POST['gender'] . '</p>
  <p>E-mail: ' . $_POST['email'] . '</p>';
}
else {
print ' --> <form action="trigger.php" name="Singupform" id="Singupform" method="post">
  <input type="hidden" id="_ACTION_" name="_ACTION_" value="sign_up_action">
    <div class="form-group">
       <label for="fname">First name:</label>
       <input type="text" class="form-control_sing-in" id="fname" name="fname" required/>
    </div>
    <div class="form-group">
       <label for="lname">Last name:</label>
       <input type="text" class="form-control_sing-in" id="lname" name="lname" required/>
    </div>
       <label for="email">e-Mail:</label>
       <input type="text" class="form-control_sing-in" id="email" name="email" required/>
       <label for="password">Password:</label>
       <input type="text" class="form-control_sing-in" id="password" name="password" required/>
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" class="form-contorl_sing-in" id="username" name="username" required/>
    </div>
    <select name="country" id="country" required>
    <option value="">Country</option>';
        <?php
          	include "dbconn.php";
            $row = @mysqli_fetch_array($result);
            $_query  = "SELECT * FROM countries";
            $_result = @mysqli_query($MySQL, $_query);
            while($_row = @mysqli_fetch_array($_result)) {
                print '<option value="' . $_row['country_code'] . '"';
                    if ($row['user_country'] == $_row['country_code']) { print " selected"; }
                print '>' . $_row['country_name'] . '</option>';
            }
    ?>
  </select>
    <div class="sing-up-button">
       <input type="submit" class="btn btn-default" value="Sign up!" />
    </div>
  </form> <!--'
 ;
}
?>
</div> -->
