﻿<?php
	
	# Work MySQL Server configuration
	$conf['MySQL']    = array(
		"Host"             => "localhost",              # MySQL hostname or IP address
		"User"             => "root",                   # MySQL user
		"Password"         => "",                       # MySQL password
		"Database"         => "webprog",                # MySQL database
	);